const forEach = require('../src/forEach');

describe('forEach', () => {
  // TODO: Put your tests here

  // Test that your callback is invoked for each array entry
  it('should invoke callback for each array entry', () => {
    const mockCB = jest.fn(); // spy
    forEach([1, 2, 3], mockCB);

    expect(mockCB.mock.calls.length).toBe(3); // we should call it 3 times
  });

  // Test that your callback arguments are provided accurately
  it('should provide accurate callback arguments', () => {
    const mockCB = jest.fn(); // spy again because apparently, each test has it's own scope
    const testArray = [1, 2, 3]; // we're gonna call this several times, so I'll declare it here
    forEach(testArray, mockCB);

    // I was having a hard time figuring out the logic for this
    // so I checked some examples online and modded them.
    // first call
    expect(mockCB.mock.calls[0][0]).toBe(1); 
    expect(mockCB.mock.calls[0][1]).toBe(0); 
    expect(mockCB.mock.calls[0][2]).toEqual(testArray); 

    // second call
    expect(mockCB.mock.calls[1][0]).toBe(2);
    expect(mockCB.mock.calls[1][1]).toBe(1); 
    expect(mockCB.mock.calls[1][2]).toEqual(testArray); 

    // third call
    expect(mockCB.mock.calls[2][0]).toBe(3); 
    expect(mockCB.mock.calls[2][1]).toBe(2); 
    expect(mockCB.mock.calls[2][2]).toEqual(testArray);
  });
});