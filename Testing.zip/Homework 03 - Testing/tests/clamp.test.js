const clamp = require('../src/clamp');

describe('clamp', () => {
  // TODO: Put your tests here
  
  // I'm not sure if the function will take 1 or 
  // three args, so I'll test all scenarios.
  it('should work with min = 0 and max = 1', () => {
    expect(clamp(0.5)).toBe(0.5);
    expect(clamp(-1)).toBe(0);
    expect(clamp(2)).toBe(1);
  });

  // Test lower bounds
  it('should apply lower boundaries based on args', () => {
    expect(clamp(-1, 0, 1)).toBe(0);
    expect(clamp(-10, -5, 5)).toBe(-5);
    expect(clamp(5, 10, 20)).toBe(10);
  });

  // Test upper bounds
  it('should apply upper boundaries based on args', () => {
    expect(clamp(2, 0, 1)).toBe(1);
    expect(clamp(10, -5, 5)).toBe(5);
    expect(clamp(25, 10, 20)).toBe(20);
  });
});
