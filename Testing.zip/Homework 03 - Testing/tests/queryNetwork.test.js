const fetch = require('../dependencies/fetch'); // we need this here too
const queryNetwork = require('../src/queryNetwork');

jest.mock('../dependencies/fetch'); // I believe this will mock fetch???

describe('queryNetwork', () => {
  // TODO: Put your tests here

  it('invokes fetch', async () => { // I didn't come up with this line, this is an example from online
    fetch.mockResolvedValue({ json: () => Promise.resolve({}) }); // Mock the fetch response
    const testUrl = 'wwcc.edu';
    await queryNetwork(testUrl);
    expect(fetch).toHaveBeenCalledWith(testUrl); // Test that fetch is invoked
  });

  it('returns the object from the json method of the fetch response', async () => {
    const mockData = { key: 'value' };
    fetch.mockResolvedValue({ json: () => Promise.resolve(mockData) }); // Mock the fetch response
    const data = await queryNetwork('wwcc.edu');
    // Test that the returned promise resolves into the object 
    // your mock is using for the json() method
    expect(data).toEqual(mockData); 
  });
});

/*
sources:

https://jestjs.io/docs/mock-function-api#mockfnmockresolvedvaluevalue


*/